package com.hasan.challengepapbuas;

public class Daftar {
    public String nama;
    public Integer idGambar;

    public Daftar(String nama, Integer idGambar) {
        this.nama = nama;
        this.idGambar = idGambar;
    }
}
